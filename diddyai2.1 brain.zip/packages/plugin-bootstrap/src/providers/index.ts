export * from "./boredom.ts";
export * from "./time.ts";
export * from "./facts.ts";
