export const confluxBridgeTransferTemplate = `
Extract Conflux Cross Space Transfer Parameters from the latest message:

{{recentMessages}}

The to address should be the Conflux eSpace address, starting with "0x".
`;
