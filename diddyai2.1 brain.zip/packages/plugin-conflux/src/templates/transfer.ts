export const confluxTransferTemplate = `
Extract Conflux Core Space Transfer Parameters from the latest message:

{{recentMessages}}

The to address should be the Conflux Core Space address, starting with "cfx:" or "cfxtest:".
`;
