# Changelog

## [0.1.0] - 2024-SEP-06

### Added

- Support for all Coinbase Advanced API REST endpoints via central client
- Custom Request and Response objects for endpoints
- Custom error types
