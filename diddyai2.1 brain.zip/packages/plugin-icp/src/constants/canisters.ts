export const CANISTER_IDS = {
    PICK_PUMP: "tl65e-yyaaa-aaaah-aq2pa-cai"
} as const;