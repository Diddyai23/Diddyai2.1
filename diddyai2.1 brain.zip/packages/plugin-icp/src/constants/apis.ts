// use your own web3 storage api host
export const WEB3_STORAGE_API_HOST = "";