# @ai16z/plugin-flow

This plugin provides basic actions and providers for interacting with the [Flow Blockchain](https://developers.flow.com/).

## Actions

### Transfer

name: `SEND_COIN`

Transfer native FLOW token/arbitrary FTs/ERC20s on Flow from agent's wallet to another EVM address or Flow address.

Message sample: `Send 5 FLOW to 0xa51d7fe9e0080662`
